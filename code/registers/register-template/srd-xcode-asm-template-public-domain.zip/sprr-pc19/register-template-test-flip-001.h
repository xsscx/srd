//
//  register-template-test-flip-001.h
//  cx.xss-app-002
//
//  Created by xss on 7/20/21.
//  Copyright © 2021 cx.xss. All rights reserved.
//

#ifndef register_template_test_flip_001_h
#define register_template_test_flip_001_h

#include <stdio.h>

#endif /* register_template_test_flip_001_h */
