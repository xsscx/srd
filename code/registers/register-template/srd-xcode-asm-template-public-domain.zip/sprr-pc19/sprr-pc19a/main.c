//
//  main.c
//  sprr-pc19a
//
//  Created by xss on 5/30/21.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
