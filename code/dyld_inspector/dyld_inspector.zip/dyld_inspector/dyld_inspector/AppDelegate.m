#import "AppDelegate.h"

typedef unsigned long u64;
typedef unsigned char u8;

extern char **environ;

@interface AppDelegate ()

@end

@implementation AppDelegate

int isReadable(u64 addr) {
    int pfds[] = { 0, 0 };
    if (pipe(pfds) != 0) {
        perror("pipe"); exit(-1);
    }
    
    ssize_t ret = write(pfds[1], (void*)addr, 8);
    
    close(pfds[0]);
    close(pfds[1]);
    return ret > 0;
}

int isWritable(u64 addr) {
    // Not technically necessary but we require it for
    // our testing and will always be the case for us...
    if (!isReadable(addr)) {
        return false;
    }
    
    int pfds[] = { 0, 0 };
    if (pipe(pfds) != 0) {
        perror("pipe"); exit(-1);
    }
    
    int v = *(int*)addr;
    ssize_t ret = write(pfds[1], &v, 4);
    if (ret != 4) {
        perror("write"); exit(-1);
    }
    
    ret = read(pfds[0], (void*)addr, 4);
    
    close(pfds[0]);
    close(pfds[1]);
    return ret > 0;
}

void inspectSharedCache() {
    u64 start = 0x180000000;
    u64 end = start + 0x100000000;
    
    for (; start < end; start += 0x4000) {
        if (isReadable(start))
            break;
    }
    
    for (; end > start; end -= 0x4000) {
        if (isReadable(end - 0x4000))
            break;
    }
    
    u64 writable_start = start;
    for (; writable_start < end; writable_start += 0x4000) {
        if (isWritable(writable_start))
            break;
    }
    
    NSMutableData* zeroMap = [NSMutableData data];
    NSMutableData* taggetPtrMap = [NSMutableData data];
    NSMutableData* pointerMap = [NSMutableData data];
        
    printf("[+] shared cache is mapped between 0x%lx and 0x%lx\n", start, end);
    printf("[+] writable region starts at 0x%lx, 0x%lx bytes from the start\n", writable_start, writable_start  - start);
    
    u8 nullMapByte = 0;
    u8 taggedPtrByte = 0;
    u8 ptrByte = 0;
    for (u64 addr = start; addr < end; addr += 8) {
        u64 val = 1;
        
        if (isReadable(addr)) {
            val = *(u64*)addr;
        }
        
        if (val == 0) {
            u8 shift = 7 - (addr % (8*8)) / 8;
            nullMapByte |= (1 << shift);
        }
        
        //  Or if val points into the shared cache (could be a objc_pointer)
        if ((val & 0x8000000000000000L) != 0) {
            u8 shift = 7 - (addr % (8*8)) / 8;
            taggedPtrByte |= (1 << shift);
        }
        
        if (val >= start && val < end) {
            u8 shift = 7 - (addr % (8*8)) / 8;
            ptrByte |= (1 << shift);
        }
        
        if (addr % (8*8) == 56) {
            [zeroMap appendBytes:&nullMapByte length:1];
            nullMapByte = 0;
            [taggetPtrMap appendBytes:&taggedPtrByte length:1];
            taggedPtrByte = 0;
            [pointerMap appendBytes:&ptrByte length:1];
            ptrByte = 0;
        }
        
        if ((addr - start) % (1*1024*1024) == 0) {
            printf("%lu/%lu\n", (addr - start) / (1*1024*1024), (end - start) / (1*1024*1024));
        }
    }
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *appFile = [documentsDirectory stringByAppendingPathComponent:@"shared_cache_nullmap.bin"];
    [zeroMap writeToFile:appFile atomically:YES];
    appFile = [documentsDirectory stringByAppendingPathComponent:@"shared_cache_tpmap.bin"];
    [taggetPtrMap writeToFile:appFile atomically:YES];
    appFile = [documentsDirectory stringByAppendingPathComponent:@"shared_cache_ptrmap.bin"];
    [pointerMap writeToFile:appFile atomically:YES];
    puts("Done. Download the shared_cache profiles via Finder now");
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
                 
    inspectSharedCache();
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
